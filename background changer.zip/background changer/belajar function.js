// Global Variabel
let i = 10

// Function
function panggilAyang(){
    // Local Variabel
    let x = 20
    console.log(x)
}

// Memanggil Function
// console.log(i)
// panggilAyang()

// Parameter
function tambah(a,b){
    console.log(a+b)
}

tambah(2,2)